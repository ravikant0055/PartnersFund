import React, { useState } from 'react';
import { IoIosArrowForward } from 'react-icons/io';

const Sidebar = ({ isOpen, closeSidebar }) => {
  return (
    <div className={`fixed top-0 right-0 h-full w-[300px] border-l bg-slate-100 border-gray-300 transition-transform  ${isOpen ? 'translate-x-0' : 'translate-x-full'}`}>
     
      <div className='flex justify-between p-4'>
        <h1 className='text-xl font-medium'>Properties</h1>
        <IoIosArrowForward className='text-3xl cursor-pointer' onClick={closeSidebar} />
      </div>

      <div className='p-4 flex flex-col gap-5'>
        <div className='flex justify-between'>
           <label htmlFor='id'>id:</label>
           <input type='text' name='id' placeholder='product id' className='px-1 ml-3 text-gray-800 outline-none rounded-md border-2 border-slate-200  placeholder:text-sm'/>
        </div>
        <div className='flex justify-between '>
           <label htmlFor='name'>name:</label>
           <input type='text' name='name' placeholder='name' className='px-1 ml-3 text-gray-800 outline-none rounded-md border-2 border-slate-200  placeholder:text-sm'/>
        </div>
        <div className='flex justify-between '>
           <label htmlFor='width'>width:</label>
           <input type='text' name='width' placeholder='width' className='px-1 ml-3 text-gray-800 outline-none rounded-md border-2 border-slate-200  placeholder:text-sm'/>
        </div>
        <div className='flex justify-between '>
           <label htmlFor='height'>height:</label>
           <input type='text' name='height' placeholder='height' className='px-1 ml-3 text-gray-800 outline-none rounded-md border-2 border-slate-200  placeholder:text-sm'/>
        </div>
        <div className='flex justify-between '>
           <label htmlFor='color'>color:</label>
           <input type='color' name='color' placeholder='color' className=' w-[192px] ml-3 text-gray-800 outline-none rounded-md border-2 border-slate-200  placeholder:text-sm'/>
        </div>
        <div className='flex justify-between '>
           <label htmlFor='id'>onClick:</label>
           <input type='text' name='id' placeholder='target location' className='px-1 ml-3 text-gray-800 outline-none rounded-md border-2 border-slate-200  placeholder:text-sm'/>
        </div>

        <div className='flex gap-2 mt-3'>
          <button className='rounded-md bg-slate-700 text-white px-3 py-1'>save</button>
          <button className='rounded-md bg-slate-700 text-white px-3 py-1'>reset</button>
        </div>
        
      </div>
    </div>
  );
};

export default Sidebar;
